<?php
require_once __DIR__ . '/../includes/security_helpers.php';
require_once __DIR__ . '/../config/db.php';

// Set security headers
setSecurityHeaders();

// Handle CORS securely
handleCors();

header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('memory_limit', '2048M');
set_time_limit(0);

$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

$method = $_SERVER['REQUEST_METHOD'];

// Log incoming request
logCampaignApiEvent('Incoming request', [
    'method' => $method,
    'action' => $_POST['action'] ?? file_get_contents('php://input'),
    'remote_addr' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
]);

try {
    if ($method === 'POST') {
        $input = getValidatedJsonInput();
        if (!$input) {
            logCampaignApiEvent('ERROR: Invalid JSON input');
            throw new InvalidArgumentException('Invalid JSON input');
        }
        
        $action = $input['action'] ?? null;
        logCampaignApiEvent("Processing action: $action", ['campaign_id' => $input['campaign_id'] ?? null]);

        if ($action === 'start_campaign') {
            $campaign_id = validateInteger($input['campaign_id'] ?? 0, 1);
            logCampaignApiEvent("Starting campaign", ['campaign_id' => $campaign_id]);
            $pid = startCampaign($conn, $campaign_id);
            logCampaignApiEvent("Campaign started successfully", ['campaign_id' => $campaign_id, 'pid' => $pid]);
            $response['success'] = true;
            $response['message'] = "Campaign #$campaign_id started successfully!";
            if ($pid) {
                $response['data'] = ['pid' => $pid];
            }
        } elseif ($action === 'pause_campaign') {
            $campaign_id = validateInteger($input['campaign_id'] ?? 0, 1);
            logCampaignApiEvent("Pausing campaign", ['campaign_id' => $campaign_id]);
            pauseCampaign($conn, $campaign_id);
            logCampaignApiEvent("Campaign paused successfully", ['campaign_id' => $campaign_id]);
            $response['success'] = true;
            $response['message'] = "Campaign #$campaign_id paused successfully!";
        } elseif ($action === 'retry_failed') {
            $campaign_id = validateInteger($input['campaign_id'] ?? 0, 1);
            logCampaignApiEvent("Retrying failed emails", ['campaign_id' => $campaign_id]);
            $msg = retryFailedEmails($conn, $campaign_id);
            logCampaignApiEvent("Retry completed", ['campaign_id' => $campaign_id, 'message' => $msg]);
            $response['success'] = true;
            $response['message'] = $msg;
        } elseif ($action === 'list') {
            logCampaignApiEvent("Fetching campaigns list");
            $response['success'] = true;
            $response['data'] = [
                'campaigns' => getCampaignsWithStats()
            ];
            logCampaignApiEvent("Campaigns fetched", ['count' => count($response['data']['campaigns'])]);
        } elseif ($action === 'email_counts') {
            $campaign_id = validateInteger($input['campaign_id'] ?? 0, 1);
            logCampaignApiEvent("Fetching email counts", ['campaign_id' => $campaign_id]);
            $response['success'] = true;
            $response['data'] = getEmailCounts($conn, $campaign_id);
        } else {
            logCampaignApiEvent("ERROR: Invalid action", ['action' => $action]);
            throw new Exception('Invalid action');
        }
    } elseif ($method === 'GET') {
        $response['success'] = true;
        $response['data'] = [
            'campaigns' => getCampaignsWithStats()
        ];
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
    logCampaignApiEvent("ERROR: Exception caught", [
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
        'method' => $method
    ]);
    logSecurityEvent('Campaign operation failed', ['error' => $e->getMessage(), 'method' => $method]);
}

logCampaignApiEvent("Sending response", ['success' => $response['success']]);
echo json_encode($response);

// Simple API event logger (append-only)
function logCampaignApiEvent($message, $context = []) {
    $logFile = __DIR__ . '/../logs/campaigns_master_api.log';
    $timestamp = date('Y-m-d H:i:s');
    $ctx = !empty($context) ? ' ' . json_encode($context) : '';
    $line = "[$timestamp] [campaigns_master] $message$ctx\n";
    file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
}

// --- Helper Functions ---

function getCampaignsWithStats()
{
    global $conn;
    
    logCampaignApiEvent("Executing getCampaignsWithStats query");
    
    $query = "SELECT 
                cm.campaign_id, 
                cm.description, 
                cm.mail_subject,
                cm.attachment_path,
                COALESCE((SELECT COUNT(*) FROM emails WHERE domain_status = 1 AND domain_processed = 1), 0) AS valid_emails,
                cs.status as campaign_status,
                COALESCE(cs.total_emails, 0) as total_emails,
                COALESCE(cs.pending_emails, 0) as pending_emails,
                COALESCE(cs.sent_emails, 0) as sent_emails,
                COALESCE(cs.failed_emails, 0) as failed_emails,
                cs.start_time,
                cs.end_time,
                (
                    SELECT COUNT(*) 
                    FROM mail_blaster mb 
                    WHERE mb.campaign_id = cm.campaign_id 
                    AND mb.status = 'pending'
                    AND mb.attempt_count < 3
                ) as retryable_count
              FROM campaign_master cm
              LEFT JOIN campaign_status cs ON cm.campaign_id = cs.campaign_id
              ORDER BY cm.campaign_id DESC";
              
    $result = $conn->query($query);
    
    if (!$result) {
        logCampaignApiEvent("ERROR: Query failed", ['error' => $conn->error]);
        throw new Exception("Database query failed: " . $conn->error);
    }
    
    $campaigns = $result->fetch_all(MYSQLI_ASSOC);
    logCampaignApiEvent("Query executed successfully", ['rows_returned' => count($campaigns)]);

    foreach ($campaigns as &$campaign) {
        $campaign['valid_emails'] = (int)($campaign['valid_emails'] ?? 0);
        $campaign['total_emails'] = (int)($campaign['total_emails'] ?? 0);
        $campaign['pending_emails'] = (int)($campaign['pending_emails'] ?? 0);
        $campaign['sent_emails'] = (int)($campaign['sent_emails'] ?? 0);
        $campaign['failed_emails'] = (int)($campaign['failed_emails'] ?? 0);
        $total = max($campaign['total_emails'], 1);
        $sent = min($campaign['sent_emails'], $total);
        $campaign['progress'] = round(($sent / $total) * 100);
    }
    
    logCampaignApiEvent("Campaigns processed", ['count' => count($campaigns)]);
    return $campaigns;
}

function startCampaign($conn, $campaign_id)
{
    $campaign_id = intval($campaign_id);
    logCampaignApiEvent("startCampaign called", ['campaign_id' => $campaign_id]);
    
    $max_retries = 5;
    $retry_count = 0;
    $success = false;
    $pid = null;
    while ($retry_count < $max_retries && !$success) {
        try {
            $conn->query("SET SESSION innodb_lock_wait_timeout = 10");
            $conn->begin_transaction();
            
            logCampaignApiEvent("Checking campaign existence", ['campaign_id' => $campaign_id]);
            $stmt = $conn->prepare("SELECT 1 FROM campaign_master WHERE campaign_id = ?");
            $stmt->bind_param("i", $campaign_id);
            $stmt->execute();
            $check = $stmt->get_result();
            $stmt->close();
            
            if ($check->num_rows == 0) {
                $conn->commit();
                logCampaignApiEvent("ERROR: Campaign not found", ['campaign_id' => $campaign_id]);
                throw new Exception("Campaign #$campaign_id does not exist");
            }
            
            logCampaignApiEvent("Checking campaign status", ['campaign_id' => $campaign_id]);
            $stmt = $conn->prepare("SELECT status FROM campaign_status WHERE campaign_id = ?");
            $stmt->bind_param("i", $campaign_id);
            $stmt->execute();
            $status_check = $stmt->get_result();
            $stmt->close();
            
            if ($status_check->num_rows > 0) {
                $current_status = $status_check->fetch_assoc()['status'];
                logCampaignApiEvent("Current status", ['campaign_id' => $campaign_id, 'status' => $current_status]);
                
                if ($current_status === 'completed') {
                    $conn->commit();
                    throw new Exception("Campaign #$campaign_id is already completed");
                }
                
                if ($current_status === 'running') {
                    $conn->commit();
                    throw new Exception("Campaign #$campaign_id is already running");
                }
            }
            
            logCampaignApiEvent("Getting email counts", ['campaign_id' => $campaign_id]);
            $counts = getEmailCounts($conn, $campaign_id);
            
            if ($status_check->num_rows > 0) {
                $stmt = $conn->prepare("UPDATE campaign_status SET 
                        status = 'running',
                        total_emails = ?,
                        pending_emails = ?,
                        sent_emails = ?,
                        failed_emails = ?,
                        start_time = IFNULL(start_time, NOW()),
                        end_time = NULL
                        WHERE campaign_id = ?");
                $stmt->bind_param("iiiii", $counts['total_valid'], $counts['pending'], $counts['sent'], $counts['failed'], $campaign_id);
                $stmt->execute();
                $stmt->close();
            } else {
                $stmt = $conn->prepare("INSERT INTO campaign_status 
                        (campaign_id, total_emails, pending_emails, sent_emails, failed_emails, status, start_time)
                        VALUES (?, ?, ?, ?, ?, 'running', NOW())");
                $stmt->bind_param("iiiii", $campaign_id, $counts['total_valid'], $counts['pending'], $counts['sent'], $counts['failed']);
                $stmt->execute();
                $stmt->close();
            }
            
            $conn->commit();
            $success = true;
            $pid = startEmailBlasterProcess($campaign_id);
            logCampaignApiEvent('Campaign started', ['campaign_id' => $campaign_id, 'pid' => $pid]);
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            if (strpos($e->getMessage(), 'Lock wait timeout exceeded') !== false) {
                $retry_count++;
                sleep(1);
                if ($retry_count >= $max_retries) {
                    throw new Exception("Failed to start campaign #$campaign_id after $max_retries attempts due to lock timeout");
                }
            } else {
                throw new Exception("Database error starting campaign #$campaign_id: " . $e->getMessage());
            }
        }
    }
    $conn->query("SET SESSION innodb_lock_wait_timeout = 50");
    return $pid;
}

function getEmailCounts($conn, $campaign_id)
{
    $campaign_id = intval($campaign_id);
    
    // Get counts directly from mail_blaster (authoritative source for campaign emails)
    // If mail_blaster is empty, fallback to emails table
    $stmt = $conn->prepare("SELECT COUNT(*) as mb_count FROM mail_blaster WHERE campaign_id = ?");
    $stmt->bind_param("i", $campaign_id);
    $stmt->execute();
    $mb_check = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($mb_check['mb_count'] > 0) {
        // Use mail_blaster as source of truth
        $stmt = $conn->prepare("SELECT 
                    COUNT(*) as total_valid,
                    SUM(CASE 
                        WHEN status IS NULL OR status = 'pending' OR (status = 'failed' AND attempt_count < 3) 
                        THEN 1 ELSE 0 
                    END) as pending,
                    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as sent,
                    SUM(CASE WHEN status = 'failed' AND attempt_count >= 3 THEN 1 ELSE 0 END) as failed
                FROM mail_blaster 
                WHERE campaign_id = ?");
        $stmt->bind_param("i", $campaign_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $counts = $result->fetch_assoc();
        $stmt->close();
    } else {
        // Fallback: count valid emails from emails table
        $result = $conn->query("SELECT COUNT(*) as total_valid FROM emails WHERE domain_status = 1 AND validation_status = 'valid'");
        $counts = $result->fetch_assoc();
        $counts['pending'] = $counts['total_valid'];
        $counts['sent'] = 0;
        $counts['failed'] = 0;
    }

    return $counts;
}

function startEmailBlasterProcess($campaign_id)
{
    logCampaignApiEvent("startEmailBlasterProcess called", ['campaign_id' => $campaign_id]);
    
    $pid_file = __DIR__ . "/../tmp/email_blaster_{$campaign_id}.pid";

    // Check if already running
    if (file_exists($pid_file)) {
        $pid = trim(file_get_contents($pid_file));
        logCampaignApiEvent("Found existing PID file", ['campaign_id' => $campaign_id, 'pid' => $pid]);
        if (is_numeric($pid) && file_exists("/proc/" . (int)$pid)) {
            logCampaignApiEvent("Process already running", ['campaign_id' => $campaign_id, 'pid' => $pid]);
            return (int)$pid; // Already running
        }
        @unlink($pid_file); // Remove stale PID file
        logCampaignApiEvent("Removed stale PID file", ['campaign_id' => $campaign_id]);
    }

    // Find PHP binary
    $php_path = '/usr/bin/php';
    if (!file_exists($php_path)) $php_path = '/usr/local/bin/php';
    if (!file_exists($php_path)) $php_path = '/opt/lampp/bin/php';
    if (!file_exists($php_path)) $php_path = 'php';
    
    logCampaignApiEvent("Using PHP binary", ['php_path' => $php_path, 'exists' => file_exists($php_path)]);
    
    // Orchestrator script
    $script = __DIR__ . '/../includes/email_sender_orchestrator.php';
    if (!file_exists($script)) {
        logCampaignApiEvent("ERROR: Orchestrator script not found", ['script' => $script]);
        throw new Exception("Email orchestrator not found: $script");
    }
    
    logCampaignApiEvent("Orchestrator script found", ['script' => $script]);
    
    // Ensure logs and tmp directories exist
    $logs_dir = __DIR__ . '/../logs';
    $tmp_dir = __DIR__ . '/../tmp';
    if (!is_dir($logs_dir)) @mkdir($logs_dir, 0777, true);
    if (!is_dir($tmp_dir)) @mkdir($tmp_dir, 0777, true);
    
    $log_path = $logs_dir . '/orchestrator_' . $campaign_id . '.log';
    
    // Spawn orchestrator in background using sh to ensure $! is available
    // Try multiple fallbacks and log when we cannot capture a PID
    $escapedPhp = escapeshellarg($php_path);
    $escapedScript = escapeshellarg($script);
    $escapedLog = escapeshellarg($log_path);

    // Use sh -c to ensure the job control and $! works consistently
    $command = sprintf("sh -c %s", escapeshellarg(sprintf('%s %s %d > %s 2>&1 & echo $!', $php_path, $script, (int)$campaign_id, $log_path)));

    logCampaignApiEvent("Executing command", ['command' => $command]);
    $pid = trim(shell_exec($command));
    logCampaignApiEvent("Command executed", ['pid' => $pid]);

    // If that failed, try a plain background without echo (fire-and-forget)
    if (!is_numeric($pid) || (int)$pid <= 0) {
        // Log the failure to capture PID
        logCampaignApiEvent('Failed to capture orchestrator PID - trying fallback', ['campaign_id' => $campaign_id, 'command' => $command, 'pid_raw' => $pid]);

        // Try fallback without echoing pid
        $fallbackCmd = sprintf('nohup %s %s %d > %s 2>&1 &', $escapedPhp, $escapedScript, (int)$campaign_id, $escapedLog);
        logCampaignApiEvent("Executing fallback command", ['fallback_cmd' => $fallbackCmd]);
        @shell_exec($fallbackCmd);

        // Attempt to find the PID by grepping process list (best-effort)
        $possible = trim(shell_exec("pgrep -f " . escapeshellarg(basename($script) . " $campaign_id")));
        if (is_numeric($possible) && (int)$possible > 0) {
            $pid = $possible;
        }
    }

    if (is_numeric($pid) && (int)$pid > 0) {
        file_put_contents($pid_file, (int)$pid);
        return (int)$pid;
    }

    // Still no PID found
    logCampaignApiEvent('Orchestrator spawn returned no PID', ['campaign_id' => $campaign_id, 'last_pid' => $pid]);
    return null;
}

function pauseCampaign($conn, $campaign_id)
{
    $campaign_id = intval($campaign_id);
    $max_retries = 3;
    $retry_count = 0;
    $success = false;
    while ($retry_count < $max_retries && !$success) {
        try {
            $conn->query("SET SESSION innodb_lock_wait_timeout = 10");
            $conn->begin_transaction();
            
            $stmt = $conn->prepare("UPDATE campaign_status SET status = 'paused' 
                    WHERE campaign_id = ? AND status = 'running'");
            $stmt->bind_param("i", $campaign_id);
            $stmt->execute();
            $affected = $stmt->affected_rows;
            $stmt->close();
            
            if ($affected > 0) {
                stopEmailBlasterProcess($campaign_id);
                $success = true;
            } else {
                $success = true;
            }
            $conn->commit();
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            if (strpos($e->getMessage(), 'Lock wait timeout exceeded') !== false) {
                $retry_count++;
                sleep(1);
                if ($retry_count >= $max_retries) {
                    throw new Exception("Failed to pause campaign #$campaign_id after $max_retries attempts due to lock timeout");
                }
            } else {
                throw new Exception("Database error pausing campaign #$campaign_id: " . $e->getMessage());
            }
        }
    }
    $conn->query("SET SESSION innodb_lock_wait_timeout = 50");
}

function stopEmailBlasterProcess($campaign_id)
{
    // Try graceful stop: read pid file and kill the process, then remove pid file
    $pid_file = __DIR__ . "/../tmp/email_blaster_{$campaign_id}.pid";
    if (file_exists($pid_file)) {
        $pid = (int)trim(file_get_contents($pid_file));
        if ($pid > 0) {
            // Send SIGTERM (15)
            @posix_kill($pid, 15);
            // Wait briefly for process to exit
            usleep(200000);
            // If still running, send SIGKILL (9)
            if (function_exists('posix_kill') && @posix_kill($pid, 0)) {
                @posix_kill($pid, 9);
            }
        }
        @unlink($pid_file);
    } else {
        // Fallback to pkill by pattern if pid file missing
        exec("pkill -f 'email_blaster.php $campaign_id'");
    }
}

function retryFailedEmails($conn, $campaign_id)
{
    $campaign_id = intval($campaign_id);
    
    $stmt = $conn->prepare("
            SELECT COUNT(*) as failed_count 
            FROM mail_blaster 
            WHERE campaign_id = ? 
            AND status = 'failed'
            AND attempt_count < 5
        ");
    $stmt->bind_param("i", $campaign_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $failed_count = $result->fetch_assoc()['failed_count'];
    $stmt->close();
    
    if ($failed_count > 0) {
        $stmt = $conn->prepare("
                UPDATE mail_blaster 
                SET status = 'pending',     
                    error_message = NULL,
                    attempt_count = attempt_count + 1
                WHERE campaign_id = ? 
                AND status = 'failed'
            ");
        $stmt->bind_param("i", $campaign_id);
        $stmt->execute();
        $stmt->close();
        
        $stmt = $conn->prepare("
                UPDATE campaign_status 
                SET pending_emails = pending_emails + ?,
                    failed_emails = GREATEST(0, failed_emails - ?),
                    status = 'running'
                WHERE campaign_id = ?
            ");
        $stmt->bind_param("iii", $failed_count, $failed_count, $campaign_id);
        $stmt->execute();
        $stmt->close();
        
        startEmailBlasterProcess($campaign_id);
        return "Retrying $failed_count failed emails for campaign #$campaign_id";
    } else {
        return "Retry campaign limit reached for campaign #$campaign_id";
    }
}