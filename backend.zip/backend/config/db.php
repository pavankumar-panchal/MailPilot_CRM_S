<?php
error_reporting(0);

// PRODUCTION DATABASE CONFIGURATION
// Database: email_id (MariaDB 5.5.68)
$dbConfig = [
    'host' => '127.0.0.1',
    'username' => 'email_id',
    'password' => '55y60jgW*',
    'name' => 'email_id',
    'port' => 3306
];

$conn = new mysqli($dbConfig['host'], $dbConfig['username'], $dbConfig['password'], $dbConfig['name'], $dbConfig['port']);

// Check connection with detailed error logging
if ($conn->connect_error) {
    $error_msg = date('[Y-m-d H:i:s] ') . "Database Connection Failed\n";
    $error_msg .= "Error: " . $conn->connect_error . "\n";
    $error_msg .= "Host: " . $dbConfig['host'] . "\n";
    $error_msg .= "Username: " . $dbConfig['username'] . "\n";
    $error_msg .= "Database: " . $dbConfig['name'] . "\n";
    $error_msg .= str_repeat('-', 80) . "\n";
    
    // Log to file
    @error_log($error_msg, 3, __DIR__ . '/../logs/db_error.log');
    
    // Return JSON error for API calls
    if (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false) {
        header('Content-Type: application/json');
        die(json_encode([
            'success' => false,
            'message' => 'Database connection failed',
            'error' => $conn->connect_error
        ]));
    } else {
        die("Database connection failed: " . $conn->connect_error);
    }
}

// Set proper character set for utf8mb4 support
$conn->set_charset("utf8mb4");
?>
