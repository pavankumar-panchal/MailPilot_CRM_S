<?php
require_once __DIR__ . '/../config/db.php';

$campaign_id = 1;
$maxRetry = 3;

echo "=== Testing Worker Query ===\n\n";

// Same query the worker uses
$sel = $conn->prepare("SELECT id, to_mail FROM mail_blaster WHERE campaign_id = ? AND (status IS NULL OR status = 'pending' OR (status = 'failed' AND attempt_count < ?)) ORDER BY id ASC LIMIT 5");
$sel->bind_param('ii', $campaign_id, $maxRetry);
$sel->execute();
$result = $sel->get_result();

echo "Query returned " . $result->num_rows . " rows\n\n";

while ($row = $result->fetch_assoc()) {
    echo "ID: {$row['id']}, Email: {$row['to_mail']}\n";
}

$sel->close();

// Check actual statuses
echo "\n=== Actual Mail Blaster Status ===\n";
$res = $conn->query("SELECT id, to_mail, status, attempt_count FROM mail_blaster WHERE campaign_id = 1 LIMIT 5");
while ($row = $res->fetch_assoc()) {
    $st = $row['status'] === null ? 'NULL' : "'{$row['status']}'";
    echo "ID: {$row['id']}, Email: {$row['to_mail']}, Status: {$st}, Attempts: {$row['attempt_count']}\n";
}

$conn->close();
