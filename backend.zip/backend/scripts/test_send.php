<?php
/**
 * Test Campaign Send - Simulates UI button click
 */

$API_URL = 'http://localhost/verify_emails/MailPilot_CRM/backend/routes/api.php/api/master/campaigns_master';

echo "=== Testing Campaign Send (like UI button) ===\n\n";

// Simulate the POST request from frontend
$data = json_encode([
    'action' => 'start_campaign',
    'campaign_id' => 1
]);

$ch = curl_init($API_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

echo "Sending request to: {$API_URL}\n";
echo "Payload: {$data}\n\n";

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: {$httpCode}\n";
echo "Response: {$response}\n\n";

$result = json_decode($response, true);

if ($result && $result['success']) {
    echo "✓ Campaign started successfully!\n";
    if (isset($result['data']['pid'])) {
        echo "  PID: {$result['data']['pid']}\n";
    }
    echo "\n";
    
    // Monitor for 10 seconds
    echo "Monitoring for 10 seconds...\n\n";
    for ($i = 0; $i < 10; $i++) {
        sleep(1);
        
        // Check status
        require_once __DIR__ . '/../config/db.php';
        $res = $conn->query("SELECT status, pending_emails, sent_emails, failed_emails FROM campaign_status WHERE campaign_id = 1");
        $status = $res->fetch_assoc();
        
        echo "  [{$i}s] Status: {$status['status']}, Pending: {$status['pending_emails']}, Sent: {$status['sent_emails']}, Failed: {$status['failed_emails']}\n";
        
        if ($status['status'] === 'completed' || ($status['pending_emails'] == 0 && $status['sent_emails'] > 0)) {
            echo "\n✓ Campaign completed!\n";
            break;
        }
    }
    
    // Final status
    echo "\n=== Final Status ===\n";
    $res = $conn->query("SELECT * FROM campaign_status WHERE campaign_id = 1");
    $final = $res->fetch_assoc();
    echo "Status: {$final['status']}\n";
    echo "Total: {$final['total_emails']}\n";
    echo "Sent: {$final['sent_emails']}\n";
    echo "Failed: {$final['failed_emails']}\n";
    echo "Pending: {$final['pending_emails']}\n";
    
    // Check some mail_blaster rows
    echo "\n=== Sample Mail Blaster Rows ===\n";
    $res = $conn->query("SELECT id, to_mail, status, smtp_email, error_message FROM mail_blaster WHERE campaign_id = 1 LIMIT 5");
    while ($row = $res->fetch_assoc()) {
        $err = $row['error_message'] ? substr($row['error_message'], 0, 50) : '';
        echo "  {$row['to_mail']}: {$row['status']} via " . ($row['smtp_email'] ?: 'N/A') . ($err ? " - {$err}..." : "") . "\n";
    }
    
    $conn->close();
} else {
    echo "✗ Failed to start campaign\n";
    if ($result && isset($result['message'])) {
        echo "Error: {$result['message']}\n";
    }
}
