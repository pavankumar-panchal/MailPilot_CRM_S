<?php
/**
 * Test Campaign Start - Simulates Frontend API Call
 */

$apiUrl = 'http://localhost/verify_emails/MailPilot_CRM/backend/routes/api.php/api/master/campaigns_master';

$data = [
    'action' => 'start_campaign',
    'campaign_id' => 1
];

echo "=== Testing Campaign Start API ===\n";
echo "URL: {$apiUrl}\n";
echo "Payload: " . json_encode($data) . "\n\n";

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: {$httpCode}\n";
echo "Response: {$response}\n\n";

$result = json_decode($response, true);
if ($result && isset($result['success'])) {
    if ($result['success']) {
        echo "✓ Campaign started successfully!\n";
        if (isset($result['data']['pid'])) {
            echo "  PID: {$result['data']['pid']}\n";
        }
        echo "  Message: {$result['message']}\n";
    } else {
        echo "❌ Failed: {$result['message']}\n";
    }
} else {
    echo "❌ Invalid response format\n";
}

// Check status after 2 seconds
echo "\nWaiting 2 seconds...\n";
sleep(2);

require_once __DIR__ . '/../config/db.php';
$result = $conn->query("SELECT * FROM campaign_status WHERE campaign_id = 1");
$status = $result->fetch_assoc();

echo "\nCampaign Status:\n";
echo "  Status: {$status['status']}\n";
echo "  Total: {$status['total_emails']}\n";
echo "  Pending: {$status['pending_emails']}\n";
echo "  Sent: {$status['sent_emails']}\n";
echo "  Failed: {$status['failed_emails']}\n";

// Check if orchestrator is running
$pid = @file_get_contents(__DIR__ . '/../tmp/email_blaster_1.pid');
if ($pid) {
    $running = file_exists("/proc/" . trim($pid));
    echo "  Orchestrator PID: " . trim($pid) . ($running ? " (running)" : " (not running)") . "\n";
}

// Check for workers
echo "\nWorker Processes:\n";
exec("ps aux | grep 'email_sender_worker.php 1' | grep -v grep", $workers);
if (empty($workers)) {
    echo "  No workers found\n";
} else {
    foreach ($workers as $worker) {
        echo "  {$worker}\n";
    }
}

$conn->close();
