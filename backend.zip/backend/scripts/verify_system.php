<?php
/**
 * System Verification Script
 * Checks database schema, columns, and system readiness
 */

require_once __DIR__ . '/../config/db.php';

echo "=== MailPilot CRM System Verification ===\n\n";

// 1. Check critical tables and columns
echo "1. Checking Database Tables:\n";
$tables = [
    'campaign_master' => ['campaign_id', 'description', 'mail_subject', 'mail_body', 'attachment_path', 'send_as_html', 'images_paths'],
    'campaign_status' => ['id', 'campaign_id', 'total_emails', 'pending_emails', 'sent_emails', 'failed_emails', 'status', 'start_time', 'end_time'],
    'mail_blaster' => ['id', 'campaign_id', 'smtp_account_id', 'smtp_email', 'to_mail', 'status', 'error_message', 'sent_at', 'attempt_count'],
    'smtp_servers' => ['id', 'name', 'host', 'port', 'encryption', 'is_active'],
    'smtp_accounts' => ['id', 'smtp_server_id', 'email', 'password', 'daily_limit', 'hourly_limit', 'is_active'],
    'smtp_usage' => ['id', 'smtp_id', 'date', 'hour', 'emails_sent'],
    'emails' => ['id', 'raw_emailid', 'domain_verified', 'domain_status', 'validation_status']
];

foreach ($tables as $table => $expectedColumns) {
    $result = $conn->query("SHOW TABLES LIKE '{$table}'");
    if ($result->num_rows == 0) {
        echo "  ❌ Table '{$table}' MISSING!\n";
        continue;
    }
    
    echo "  ✓ Table '{$table}' exists\n";
    
    $result = $conn->query("SHOW COLUMNS FROM {$table}");
    $actualColumns = [];
    while ($row = $result->fetch_assoc()) {
        $actualColumns[] = $row['Field'];
    }
    
    foreach ($expectedColumns as $col) {
        if (!in_array($col, $actualColumns)) {
            echo "    ⚠ Missing column: {$col}\n";
        }
    }
}

// 2. Check campaign data
echo "\n2. Campaign Data:\n";
$result = $conn->query("SELECT COUNT(*) as count FROM campaign_master");
$count = $result->fetch_assoc()['count'];
echo "  Total campaigns: {$count}\n";

if ($count > 0) {
    $result = $conn->query("SELECT campaign_id, description FROM campaign_master LIMIT 3");
    while ($row = $result->fetch_assoc()) {
        echo "    - Campaign {$row['campaign_id']}: {$row['description']}\n";
        
        // Check mail_blaster entries
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM mail_blaster WHERE campaign_id = ?");
        $stmt->bind_param('i', $row['campaign_id']);
        $stmt->execute();
        $mbCount = $stmt->get_result()->fetch_assoc()['count'];
        echo "      Mail blaster entries: {$mbCount}\n";
    }
}

// 3. Check SMTP configuration
echo "\n3. SMTP Configuration:\n";
$result = $conn->query("SELECT COUNT(*) as count FROM smtp_servers WHERE is_active = 1");
$count = $result->fetch_assoc()['count'];
echo "  Active SMTP servers: {$count}\n";

$result = $conn->query("SELECT COUNT(*) as count FROM smtp_accounts WHERE is_active = 1");
$count = $result->fetch_assoc()['count'];
echo "  Active SMTP accounts: {$count}\n";

if ($count > 0) {
    $result = $conn->query("SELECT s.name, s.host, s.port, s.encryption, COUNT(a.id) as account_count 
                            FROM smtp_servers s 
                            LEFT JOIN smtp_accounts a ON a.smtp_server_id = s.id AND a.is_active = 1
                            WHERE s.is_active = 1
                            GROUP BY s.id 
                            LIMIT 5");
    while ($row = $result->fetch_assoc()) {
        echo "    - {$row['name']}: {$row['host']}:{$row['port']} ({$row['encryption']}) - {$row['account_count']} accounts\n";
    }
}

// 4. Check mail_blaster unique constraint
echo "\n4. Checking mail_blaster integrity:\n";
$result = $conn->query("SELECT campaign_id, to_mail, COUNT(*) as cnt 
                        FROM mail_blaster 
                        GROUP BY campaign_id, to_mail 
                        HAVING cnt > 1 
                        LIMIT 5");
$dupes = 0;
while ($row = $result->fetch_assoc()) {
    $dupes++;
    echo "  ⚠ Duplicate: Campaign {$row['campaign_id']}, Email {$row['to_mail']} ({$row['cnt']} times)\n";
}
if ($dupes == 0) {
    echo "  ✓ No duplicate (campaign_id, to_mail) pairs found\n";
}

// 5. Check file structure
echo "\n5. Checking File Structure:\n";
$criticalFiles = [
    '../includes/email_sender_orchestrator.php' => 'Orchestrator',
    '../includes/email_sender_worker.php' => 'Worker',
    '../includes/smtp_usage.php' => 'SMTP Usage Helper',
    '../public/campaigns_master.php' => 'Campaign Master API',
    '../config/db.php' => 'Database Config'
];

foreach ($criticalFiles as $path => $name) {
    $fullPath = __DIR__ . '/' . $path;
    if (file_exists($fullPath)) {
        echo "  ✓ {$name}\n";
    } else {
        echo "  ❌ {$name} MISSING: {$fullPath}\n";
    }
}

// 6. Check PHP extensions
echo "\n6. PHP Extensions:\n";
$requiredExtensions = ['mysqli', 'json', 'mbstring'];
foreach ($requiredExtensions as $ext) {
    if (extension_loaded($ext)) {
        echo "  ✓ {$ext}\n";
    } else {
        echo "  ❌ {$ext} NOT LOADED\n";
    }
}

// 7. Check PHPMailer
echo "\n7. PHPMailer:\n";
$phpmailerPath = __DIR__ . '/../vendor/phpmailer/phpmailer/src/PHPMailer.php';
if (file_exists($phpmailerPath)) {
    echo "  ✓ PHPMailer installed\n";
} else {
    echo "  ❌ PHPMailer NOT FOUND\n";
}

echo "\n=== Verification Complete ===\n";

$conn->close();
