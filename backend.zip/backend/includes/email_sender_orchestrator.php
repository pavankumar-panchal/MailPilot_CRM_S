<?php
// Simple orchestrator wrapper for launching the parallel email blaster daemon.
// This file is called by the web API (via shell_exec) and must be runnable
// by the PHP CLI with a single numeric campaign id argument.

error_reporting(E_ALL);
ini_set('display_errors', 0);
set_time_limit(0);

// Only allow CLI execution
if (php_sapi_name() !== 'cli') {
    echo "This script must be run from CLI\n";
    http_response_code(400);
    exit(1);
}

$campaign_id = isset($argv[1]) ? intval($argv[1]) : 0;
if ($campaign_id <= 0) {
    fwrite(STDERR, "ERROR: campaign_id argument required\n");
    exit(1);
}

$parallel_script = __DIR__ . '/email_blast_parallel.php';
if (!file_exists($parallel_script)) {
    fwrite(STDERR, "ERROR: parallel script not found at $parallel_script\n");
    exit(1);
}

// Execute the parallel script in the current process so PID matches the
// background process spawned by startEmailBlasterProcess (which runs this file).
// We simply require the file; it will detect CLI and start its daemon loop.
require $parallel_script;

exit(0);
