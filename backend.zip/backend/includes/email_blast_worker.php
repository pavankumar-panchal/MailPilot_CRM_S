<?php
// Email Blast Worker Script
// This script is spawned by the parallel email blaster to send emails in parallel

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';

error_reporting(E_ALL);
ini_set('display_errors', 0);
set_time_limit(0);

// Parse arguments
$campaign_id = isset($argv[1]) ? intval($argv[1]) : 0;
$email_ids_str = isset($argv[2]) ? $argv[2] : '';
$server_config = isset($argv[3]) ? json_decode($argv[3], true) : [];
$account_config = isset($argv[4]) ? json_decode($argv[4], true) : [];
$campaign = isset($argv[5]) ? json_decode($argv[5], true) : [];

if ($campaign_id == 0 || empty($email_ids_str) || empty($server_config) || empty($account_config)) {
    exit(1);
}

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'CRM');
$conn->set_charset("utf8mb4");
if ($conn->connect_error) {
    exit(1);
}

// Get email IDs
$email_ids = array_filter(explode(',', $email_ids_str), 'is_numeric');
if (empty($email_ids)) {
    exit(0);
}

// Fetch emails
$id_list = implode(',', $email_ids);
$result = $conn->query("
    SELECT id, raw_emailid FROM emails 
    WHERE id IN ($id_list) AND domain_status = 1
");

$emails = [];
while ($row = $result->fetch_assoc()) {
    $emails[] = $row;
}

// Process each email
foreach ($emails as $email) {
    try {
        sendEmail($conn, $campaign_id, $email['raw_emailid'], $server_config, $account_config, $campaign);
        usleep(100000); // 100ms between emails
    } catch (Exception $e) {
        // Error already logged in sendEmail
    }
}

$conn->close();
exit(0);

/**
 * Send email using PHPMailer
 */
function sendEmail($conn, $campaign_id, $to_email, $server, $account, $campaign) {
    // Validate email format before attempting to send
    if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Invalid email format: $to_email");
    }
    
    $to_email = trim($to_email);
    if (empty($to_email) || strlen($to_email) > 254) {
        throw new Exception("Email address too long or empty: $to_email");
    }
    
    $mail = new PHPMailer(true);
    
    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = $server['host'];
        $mail->Port = $server['port'];
        $mail->SMTPAuth = true;
        $mail->Username = $account['email'];
        $mail->Password = $account['password'];
        $mail->Timeout = 30;
        $mail->SMTPDebug = 0;
        $mail->SMTPKeepAlive = false;
        
        if ($server['encryption'] === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($server['encryption'] === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }
        
        // Enhanced SMTPOptions for maximum compatibility - CRITICAL!
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
                'crypto_method' => STREAM_CRYPTO_METHOD_TLS_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT
            ]
        ];
        
        // Enable automatic retry on connection failure
        $mail->SMTPAutoTLS = true;
        
        $mail->setFrom($account['email']);
        $mail->addAddress($to_email);
        $mail->Subject = $campaign['mail_subject'];
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        
        // Add headers for better deliverability
        $mail->XMailer = ' '; // Hide X-Mailer header to avoid spam filters
        $mail->addCustomHeader('MIME-Version', '1.0');
        $mail->addCustomHeader('X-Priority', '3');
        $mail->addCustomHeader('X-MSMail-Priority', 'Normal');
        $mail->addCustomHeader('Importance', 'Normal');
        
        // Set HTML mode
        $isHtml = !empty($campaign['send_as_html']);
        $mail->isHTML($isHtml);
        
        // Reply-To with proper clearing
        if (!empty($campaign['reply_to'])) {
            $mail->clearReplyTos();
            $mail->addReplyTo($campaign['reply_to']);
        } elseif (!empty($server['received_email'])) {
            $mail->clearReplyTos();
            $mail->addReplyTo($server['received_email']);
        }
        
        // Add attachment
        if (!empty($campaign['attachment_path'])) {
            $attachmentPath = __DIR__ . '/../' . $campaign['attachment_path'];
            if (file_exists($attachmentPath)) {
                $mail->addAttachment($attachmentPath);
            }
        }
        
        // Process body
        $body = $campaign['mail_body'];
        
        // Validate body is not empty
        if (empty(trim($body))) {
            throw new Exception("Message body is empty. Cannot send email to $to_email");
        }
        
        // Add embedded images
        if (!empty($campaign['images_paths'])) {
            $images = is_string($campaign['images_paths']) 
                ? json_decode($campaign['images_paths'], true) 
                : $campaign['images_paths'];
            
            if (is_array($images)) {
                foreach ($images as $index => $imagePath) {
                    $fullPath = __DIR__ . '/../' . $imagePath;
                    if (file_exists($fullPath)) {
                        $cid = 'image_' . $index . '_' . uniqid();
                        $mail->addEmbeddedImage($fullPath, $cid);
                        
                        if ($isHtml) {
                            $filename = basename($imagePath);
                            $escapedPath = preg_quote($imagePath, '/');
                            $escapedFilename = preg_quote($filename, '/');
                            
                            $count = 0;
                            $body = preg_replace(
                                '/(<img[^>]+src=["\'])[^"\']*' . $escapedPath . '(["\'])/i',
                                '${1}cid:' . $cid . '${2}',
                                $body,
                                -1,
                                $count
                            );
                            
                            if ($count == 0) {
                                $body = preg_replace(
                                    '/(<img[^>]+src=["\'])[^"\']*' . $escapedFilename . '(["\'])/i',
                                    '${1}cid:' . $cid . '${2}',
                                    $body
                                );
                            }
                        }
                    }
                }
            }
        }
        
        $mail->Body = $body;
        if ($isHtml) {
            $mail->AltBody = strip_tags($body);
        }
        
        // Final validation before sending
        if (empty(trim($mail->Body))) {
            throw new Exception("Message body became empty during processing");
        }
        
        // Send email
        if (!$mail->send()) {
            throw new Exception($mail->ErrorInfo);
        }
        
        // Record success
        recordDelivery($conn, $account['id'], $campaign_id, $to_email, 'success');
        updateCampaignStats($conn, $campaign_id, 'success');
        
    } catch (Exception $e) {
        // Record failure
        recordDelivery($conn, $account['id'], $campaign_id, $to_email, 'failed', $e->getMessage());
        updateCampaignStats($conn, $campaign_id, 'failed');
    }
}

function recordDelivery($conn, $smtp_account_id, $campaign_id, $to_email, $status, $error = null) {
    // Check if this email was already sent successfully
    $check = $conn->query("
        SELECT status FROM mail_blaster 
        WHERE campaign_id = $campaign_id AND to_mail = '$to_email' AND status = 'success'
        LIMIT 1
    ");
    
    if ($check && $check->num_rows > 0) {
        // Already sent successfully, don't record again
        return;
    }
    
    $stmt = $conn->prepare("
        INSERT INTO mail_blaster 
        (campaign_id, to_mail, smtpid, delivery_date, delivery_time, status, error_message, attempt_count)
        VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, ?, 1)
        ON DUPLICATE KEY UPDATE
            smtpid = VALUES(smtpid),
            delivery_date = VALUES(delivery_date),
            delivery_time = VALUES(delivery_time),
            status = IF(mail_blaster.status = 'success', 'success', VALUES(status)),
            error_message = IF(VALUES(status) = 'failed', VALUES(error_message), NULL),
            attempt_count = IF(mail_blaster.status = 'success', mail_blaster.attempt_count, mail_blaster.attempt_count + 1)
    ");
    
    $stmt->bind_param("isiss", $campaign_id, $to_email, $smtp_account_id, $status, $error);
    $stmt->execute();
    $stmt->close();
}

function updateCampaignStats($conn, $campaign_id, $result) {
    // This prevents double counting and mismatches
    return;
}