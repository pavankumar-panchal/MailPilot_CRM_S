<?php


error_reporting(E_ALL);
ini_set('display_errors', 0); // Production safe
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');
set_time_limit(0);
ini_set('memory_limit', '4096M');

date_default_timezone_set('Asia/Kolkata');
// Determine execution mode: CLI daemon or web-trigger that launches the CLI daemon in background
// Support both: when run from CLI the script becomes the daemon; when invoked via web (browser/XHR)
// it will spawn the CLI daemon in background and return immediately.

// Helper to check if a PID is running (works on Linux with /proc)
function isPidRunning($pid) {
    if ($pid <= 0) return false;
    return file_exists('/proc/' . intval($pid));
}

$pid_dir = __DIR__ . '/../tmp';
if (!is_dir($pid_dir)) {
    @mkdir($pid_dir, 0777, true);
}

// Web invocation: spawn background CLI daemon and return JSON
if (php_sapi_name() !== 'cli') {
    // Accept campaign_id via GET/POST (prefer POST)
    $campaign_id = isset($_REQUEST['campaign_id']) ? intval($_REQUEST['campaign_id']) : 0;
    if ($campaign_id <= 0) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'campaign_id is required']);
        exit;
    }

    $pid_file = $pid_dir . "/email_blaster_{$campaign_id}.pid";

    // If pid exists and process is running, report already started
    if (file_exists($pid_file)) {
        $existing = intval(@file_get_contents($pid_file));
        if ($existing > 0 && isPidRunning($existing)) {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'ok', 'message' => 'Daemon already running', 'pid' => $existing]);
            exit;
        } else {
            // Stale PID file - remove
            @unlink($pid_file);
        }
    }

    // Build command to launch this same file in CLI mode
    $php_bin = defined('PHP_BINARY') ? PHP_BINARY : 'php';
    $script = __FILE__;

    // Try to capture the background PID using shell features
    $cmd = sprintf('%s %s %d > /dev/null 2>&1 & echo $!', escapeshellarg($php_bin), escapeshellarg($script), $campaign_id);
    exec($cmd, $output, $ret);
    $newpid = isset($output[0]) ? intval($output[0]) : 0;

    if ($newpid > 0) {
        // Persist pid file for bookkeeping
        @file_put_contents($pid_file, $newpid);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'ok', 'message' => 'Daemon started', 'pid' => $newpid]);
        exit;
    }

    // Fallback: try without echoing pid (fire-and-forget)
    $cmd2 = sprintf('%s %s %d > /dev/null 2>&1 &', escapeshellarg($php_bin), escapeshellarg($script), $campaign_id);
    exec($cmd2, $out2, $r2);
    // Don't have PID, but assume started
    header('Content-Type: application/json');
    echo json_encode(['status' => 'ok', 'message' => 'Daemon started (pid unknown)']);
    exit;
}

// CLI mode continues below - get campaign_id from argv
$campaign_id = isset($argv[1]) ? intval($argv[1]) : 0;
if ($campaign_id == 0) {
    die("ERROR: Campaign ID required as argument\n");
}

// Create PID file for process tracking (CLI daemon)
$pid_file = $pid_dir . "/email_blaster_{$campaign_id}.pid";
file_put_contents($pid_file, getmypid());

// Register shutdown function to clean up PID file
register_shutdown_function(function () use ($pid_file) {
    if (file_exists($pid_file)) {
        @unlink($pid_file);
    }
});

// Configuration
define('MAX_WORKERS_PER_SERVER', 10); // Workers per SMTP server
define('EMAILS_PER_WORKER', 100); // Emails processed per worker batch
define('WORKER_SCRIPT', __DIR__ . '/email_blast_worker.php');
define('LOG_FILE', __DIR__ . '/../logs/email_blast_parallel_' . date('Y-m-d') . '.log');
define('RETRY_FAILED_AFTER_CYCLE', true); // Retry failed emails after one complete cycle
define('MAX_RETRY_ATTEMPTS', 3); // Maximum retry attempts per email
define('RETRY_DELAY_SECONDS', 5); // Delay between retry cycles

/**
 * Reset daily counters if it's a new day
 */
function resetDailyCountersIfNeeded($conn) {
    // Check if we need to reset daily counters
    $reset_check = $conn->query("
        SELECT DATE(NOW()) as today,
               MAX(DATE(mb.delivery_time)) as last_send_date
        FROM mail_blaster mb
        WHERE mb.delivery_date = CURDATE()
        LIMIT 1
    ");
    
    if ($reset_check && $reset_check->num_rows > 0) {
        $dates = $reset_check->fetch_assoc();
        
        // If today is different from last send date, or no sends yet today
        if (!$dates['last_send_date'] || $dates['today'] != $dates['last_send_date']) {
            // Check if any accounts have sent_today > 0
            $need_reset = $conn->query("SELECT COUNT(*) as cnt FROM smtp_accounts WHERE sent_today > 0");
            $result = $need_reset->fetch_assoc();
            
            if ($result['cnt'] > 0) {
                // Reset all daily counters
                $conn->query("UPDATE smtp_accounts SET sent_today = 0 WHERE sent_today > 0");
                logMessage("Daily counters reset for new day");
            }
        }
    }
}

/**
 * Check if an account is within its hourly and daily limits
 */
function isAccountWithinLimits($conn, $account_id) {
    $query = $conn->query("
        SELECT sa.daily_limit, sa.hourly_limit, sa.sent_today,
               COUNT(mb.id) as sent_this_hour
        FROM smtp_accounts sa
        LEFT JOIN mail_blaster mb ON mb.smtpid = sa.id 
            AND mb.delivery_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            AND mb.status = 'success'
        WHERE sa.id = $account_id
        GROUP BY sa.id
    ");
    
    if ($query && $query->num_rows > 0) {
        $limits = $query->fetch_assoc();
        
        // Check daily limit (0 means unlimited)
        if ($limits['daily_limit'] > 0 && $limits['sent_today'] >= $limits['daily_limit']) {
            return false;
        }
        
        // Check hourly limit (0 means unlimited)
        if ($limits['hourly_limit'] > 0 && $limits['sent_this_hour'] >= $limits['hourly_limit']) {
            return false;
        }
        
        return true;
    }
    
    return false;
}

/**
 * Get remaining quota for an account
 */
function getAccountQuota($conn, $account_id) {
    $query = $conn->query("
        SELECT sa.daily_limit, sa.hourly_limit, sa.sent_today,
               COUNT(mb.id) as sent_this_hour
        FROM smtp_accounts sa
        LEFT JOIN mail_blaster mb ON mb.smtpid = sa.id 
            AND mb.delivery_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            AND mb.status = 'success'
        WHERE sa.id = $account_id
        GROUP BY sa.id
    ");
    
    if ($query && $query->num_rows > 0) {
        $data = $query->fetch_assoc();
        
        $daily_remaining = ($data['daily_limit'] > 0) 
            ? max(0, $data['daily_limit'] - $data['sent_today']) 
            : PHP_INT_MAX;
            
        $hourly_remaining = ($data['hourly_limit'] > 0) 
            ? max(0, $data['hourly_limit'] - $data['sent_this_hour']) 
            : PHP_INT_MAX;
        
        return [
            'daily_remaining' => $daily_remaining,
            'hourly_remaining' => $hourly_remaining,
            'can_send' => ($daily_remaining > 0 && $hourly_remaining > 0)
        ];
    }
    
    return ['daily_remaining' => 0, 'hourly_remaining' => 0, 'can_send' => false];
}

/**
 * Main execution function
 */
function runParallelEmailBlast($conn, $campaign_id) {
    logMessage("Starting parallel email blast for campaign #$campaign_id");
    
    // Step 0: Create worker script first
    createWorkerScript();
    logMessage("Worker script ready at " . WORKER_SCRIPT);
    
    // Step 1: Get campaign details
    $campaign = getCampaignDetails($conn, $campaign_id);
    if (!$campaign) {
        return ["status" => "error", "message" => "Campaign not found"];
    }
    
    // Step 2: Get all active SMTP servers with their accounts
    $smtp_servers = getSmtpServersWithAccounts($conn);
    if (empty($smtp_servers)) {
        return ["status" => "error", "message" => "No active SMTP servers/accounts found"];
    }
    
    logMessage("Found " . count($smtp_servers) . " active SMTP servers");
    $total_accounts = 0;
    foreach ($smtp_servers as $server) {
        $total_accounts += count($server['accounts']);
        logMessage("Server #{$server['id']} ({$server['name']}): " . count($server['accounts']) . " accounts");
    }
    
    // Step 3: Get emails to send (not yet successfully sent)
    $emails_to_send = getEmailsToSend($conn, $campaign_id);
    $total_emails = count($emails_to_send);
    
    if ($total_emails == 0) {
        return ["status" => "success", "message" => "No emails to send"];
    }
    
    logMessage("Total emails to send: $total_emails");
    logMessage("Total SMTP accounts available: $total_accounts");
    
    // Step 4: Calculate optimal batch size and worker count
    $batch_config = calculateBatchConfig($total_emails, $total_accounts, count($smtp_servers));
    logMessage("Batch configuration: " . json_encode($batch_config));
    
    // Step 5: Distribute emails across servers and accounts
    $distribution = distributeEmailsAcrossServers($emails_to_send, $smtp_servers, $batch_config);
    
        // Step 6: Launch parallel workers
    $result = launchParallelWorkers($conn, $campaign_id, $distribution, $campaign);
    
    // Step 7: Multiple retry cycles for failed emails
    if (RETRY_FAILED_AFTER_CYCLE) {
        $retry_attempt = 1;
        
        while ($retry_attempt <= MAX_RETRY_ATTEMPTS) {
            // Wait a bit before retry
            if ($retry_attempt > 1) {
                logMessage("Waiting " . RETRY_DELAY_SECONDS . " seconds before retry attempt #$retry_attempt");
                sleep(RETRY_DELAY_SECONDS);
            }
            
            // Get fresh list of SMTP servers (exclude failed ones)
            $working_servers = getWorkingSmtpServers($conn);
            if (empty($working_servers)) {
                logMessage("No working SMTP servers available for retry");
                break;
            }
            
            $failed_count = retryFailedEmails($conn, $campaign_id, $working_servers, $campaign, $retry_attempt);
            
            if ($failed_count > 0) {
                logMessage("Retry attempt #$retry_attempt: Retried $failed_count failed emails");
            } else {
                logMessage("No more failed emails to retry");
                break;
            }
            
            $retry_attempt++;
        }
    }
    
    // ALWAYS update final stats and check for completion
    updateFinalCampaignStats($conn, $campaign_id);
    
    return $result;
}

/**
 * Get campaign details
 */
function getCampaignDetails($conn, $campaign_id) {
    $result = $conn->query("
        SELECT * FROM campaign_master 
        WHERE campaign_id = $campaign_id
    ");
    
    if ($result && $result->num_rows > 0) {
        $campaign = $result->fetch_assoc();
        // Normalize mail_body
        if (isset($campaign['mail_body'])) {
            $campaign['mail_body'] = stripcslashes($campaign['mail_body']);
        }
        return $campaign;
    }
    return null;
}

/**
 * Get all active SMTP servers with their accounts (respecting daily/hourly limits)
 */
function getSmtpServersWithAccounts($conn) {
    $servers = [];
    
    // Reset daily counters if it's a new day
    resetDailyCountersIfNeeded($conn);
    
    // Get all active servers
    $server_result = $conn->query("
        SELECT id, name, host, port, encryption, received_email 
        FROM smtp_servers 
        WHERE is_active = 1 
        ORDER BY id ASC
    ");
    
    while ($server = $server_result->fetch_assoc()) {
        // Get accounts that are within their limits
        $account_result = $conn->query("
            SELECT sa.id, sa.email, sa.password, sa.daily_limit, sa.hourly_limit, 
                   sa.sent_today, sa.total_sent,
                   COALESCE(hourly.sent_count, 0) as sent_this_hour
            FROM smtp_accounts sa
            LEFT JOIN (
                SELECT smtpid, COUNT(*) as sent_count
                FROM mail_blaster
                WHERE delivery_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
                AND status = 'success'
                GROUP BY smtpid
            ) hourly ON hourly.smtpid = sa.id
            WHERE sa.smtp_server_id = {$server['id']} 
            AND sa.is_active = 1
            AND (sa.daily_limit = 0 OR sa.sent_today < sa.daily_limit)
            AND (sa.hourly_limit = 0 OR COALESCE(hourly.sent_count, 0) < sa.hourly_limit)
            ORDER BY sa.id ASC
        ");
        
        $accounts = [];
        while ($account = $account_result->fetch_assoc()) {
            $accounts[] = $account;
        }
        
        // Only include servers that have available accounts
        if (!empty($accounts)) {
            $server['accounts'] = $accounts;
            $servers[] = $server;
            logMessage("Server {$server['name']}: " . count($accounts) . " accounts available (within limits)");
        } else {
            logMessage("Server {$server['name']}: No accounts available (all at limit)");
        }
    }
    
    return $servers;
}

/**
 * Get working SMTP servers (exclude recently failed ones, respect limits)
 */
function getWorkingSmtpServers($conn) {
    $servers = [];
    
    // Reset daily counters if it's a new day
    resetDailyCountersIfNeeded($conn);
    
    // Get servers that have sent successfully in the last 10 minutes
    // OR have no recent failures
    $server_result = $conn->query("
        SELECT DISTINCT ss.id, ss.name, ss.host, ss.port, ss.encryption, ss.received_email
        FROM smtp_servers ss
        WHERE ss.is_active = 1
        AND (
            -- Servers with recent successes
            EXISTS (
                SELECT 1 FROM mail_blaster mb
                JOIN smtp_accounts sa ON sa.id = mb.smtpid
                WHERE sa.smtp_server_id = ss.id
                AND mb.status = 'success'
                AND mb.delivery_date = CURDATE()
                AND mb.delivery_time >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
            )
            OR
            -- Servers with no recent failures
            NOT EXISTS (
                SELECT 1 FROM mail_blaster mb
                JOIN smtp_accounts sa ON sa.id = mb.smtpid
                WHERE sa.smtp_server_id = ss.id
                AND mb.status = 'failed'
                AND mb.delivery_date = CURDATE()
                AND mb.delivery_time >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            )
        )
        ORDER BY ss.id ASC
    ");
    
    while ($server = $server_result->fetch_assoc()) {
        // Get accounts that are within their limits
        $account_result = $conn->query("
            SELECT sa.id, sa.email, sa.password, sa.daily_limit, sa.hourly_limit, 
                   sa.sent_today, sa.total_sent,
                   COALESCE(hourly.sent_count, 0) as sent_this_hour
            FROM smtp_accounts sa
            LEFT JOIN (
                SELECT smtpid, COUNT(*) as sent_count
                FROM mail_blaster
                WHERE delivery_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
                AND status = 'success'
                GROUP BY smtpid
            ) hourly ON hourly.smtpid = sa.id
            WHERE sa.smtp_server_id = {$server['id']} 
            AND sa.is_active = 1
            AND (sa.daily_limit = 0 OR sa.sent_today < sa.daily_limit)
            AND (sa.hourly_limit = 0 OR COALESCE(hourly.sent_count, 0) < sa.hourly_limit)
            ORDER BY id ASC
        ");
        
        $accounts = [];
        while ($account = $account_result->fetch_assoc()) {
            $accounts[] = $account;
        }
        
        if (!empty($accounts)) {
            $server['accounts'] = $accounts;
            $servers[] = $server;
        }
    }
    
    // If no working servers found, fall back to all active servers
    if (empty($servers)) {
        return getSmtpServersWithAccounts($conn);
    }
    
    return $servers;
}

/**
 * Get emails that need to be sent
 */
function getEmailsToSend($conn, $campaign_id) {
    $result = $conn->query("
        SELECT e.id, e.raw_emailid
        FROM emails e
        WHERE e.domain_status = 1
        AND NOT EXISTS (
            SELECT 1 FROM mail_blaster mb 
            WHERE mb.to_mail = e.raw_emailid 
            AND mb.campaign_id = $campaign_id
            AND mb.status = 'success'
        )
        ORDER BY e.id ASC
    ");
    
    $emails = [];
    while ($row = $result->fetch_assoc()) {
        $emails[] = $row;
    }
    
    return $emails;
}

/**
 * Calculate optimal batch configuration
 */
function calculateBatchConfig($total_emails, $total_accounts, $total_servers) {
    // Calculate workers per server based on available accounts
    $avg_accounts_per_server = ceil($total_accounts / $total_servers);
    $workers_per_server = min(MAX_WORKERS_PER_SERVER, $avg_accounts_per_server);
    
    // Calculate emails per worker
    $total_workers = $workers_per_server * $total_servers;
    $emails_per_worker = ceil($total_emails / $total_workers);
    $emails_per_worker = min($emails_per_worker, EMAILS_PER_WORKER);
    
    return [
        'workers_per_server' => $workers_per_server,
        'emails_per_worker' => $emails_per_worker,
        'total_workers' => $total_workers
    ];
}

/**
 * Distribute emails across servers and their accounts
 */
function distributeEmailsAcrossServers($emails, $smtp_servers, $batch_config) {
    $distribution = [];
    $email_index = 0;
    $total_emails = count($emails);
    
    // Round-robin distribution across servers
    foreach ($smtp_servers as $server_idx => $server) {
        $server_id = $server['id'];
        $accounts = $server['accounts'];
        $workers_for_server = $batch_config['workers_per_server'];
        
        for ($worker_id = 0; $worker_id < $workers_for_server; $worker_id++) {
            if ($email_index >= $total_emails) break;
            
            // Assign emails to this worker
            $worker_emails = [];
            for ($i = 0; $i < $batch_config['emails_per_worker']; $i++) {
                if ($email_index >= $total_emails) break;
                $worker_emails[] = $emails[$email_index];
                $email_index++;
            }
            
            if (!empty($worker_emails)) {
                // Assign account for this worker (round-robin within server)
                $account_idx = $worker_id % count($accounts);
                $account = $accounts[$account_idx];
                
                $distribution[] = [
                    'server_id' => $server_id,
                    'server' => $server,
                    'account' => $account,
                    'worker_id' => $worker_id,
                    'emails' => $worker_emails
                ];
            }
        }
        
        if ($email_index >= $total_emails) break;
    }
    
    return $distribution;
}

/**
 * Launch parallel workers for email sending
 */
function launchParallelWorkers($conn, $campaign_id, $distribution, $campaign) {
    logMessage("Launching " . count($distribution) . " parallel workers");
    
    $processes = [];
    $start_time = microtime(true);
    
    // Verify worker script exists
    if (!file_exists(WORKER_SCRIPT)) {
        logMessage("ERROR: Worker script not found at " . WORKER_SCRIPT);
        return ["status" => "error", "message" => "Worker script not created"];
    }
    
    // Launch all workers in parallel
    foreach ($distribution as $idx => $work) {
        $email_ids = array_column($work['emails'], 'id');
        $email_ids_str = implode(',', $email_ids);
        
        $server_config = json_encode([
            'host' => $work['server']['host'],
            'port' => $work['server']['port'],
            'encryption' => $work['server']['encryption'],
            'received_email' => $work['server']['received_email']
        ]);
        
        $account_config = json_encode([
            'id' => $work['account']['id'],
            'email' => $work['account']['email'],
            'password' => $work['account']['password'],
            'daily_limit' => $work['account']['daily_limit'],
            'hourly_limit' => $work['account']['hourly_limit']
        ]);
        
        $campaign_json = json_encode($campaign);
        
        $cmd = sprintf(
            'php %s %d %s %s %s %s > /dev/null 2>&1 &',
            escapeshellarg(WORKER_SCRIPT),
            $campaign_id,
            escapeshellarg($email_ids_str),
            escapeshellarg($server_config),
            escapeshellarg($account_config),
            escapeshellarg($campaign_json)
        );
        
        exec($cmd, $output, $return_var);
        $email_count = count($work['emails']);
        $processes[] = [
            'worker_id' => $idx,
            'server_id' => $work['server_id'],
            'account_email' => $work['account']['email'],
            'email_count' => $email_count
        ];
        
        logMessage("Launched worker #$idx for server #{$work['server_id']} with account {$work['account']['email']} ($email_count emails)");
        
        usleep(50000); // 50ms delay between worker launches
    }
    
    // Wait for all workers to complete
    $max_wait = 3600; // 1 hour max
    $waited = 0;
    $check_interval = 5; // Check every 5 seconds
    
    while ($waited < $max_wait) {
        sleep($check_interval);
        $waited += $check_interval;
        
        // Check if all emails are processed
        $pending = $conn->query("
            SELECT COUNT(*) as cnt FROM emails e
            WHERE e.domain_status = 1
            AND NOT EXISTS (
                SELECT 1 FROM mail_blaster mb 
                WHERE mb.to_mail = e.raw_emailid 
                AND mb.campaign_id = $campaign_id
                AND mb.status IN ('success', 'failed')
            )
        ")->fetch_assoc()['cnt'];
        
        if ($pending == 0) {
            logMessage("All workers completed processing");
            break;
        }
        
        if ($waited % 30 == 0) { // Log every 30 seconds
            logMessage("Still processing... $pending emails pending");
        }
    }
    
    $elapsed = microtime(true) - $start_time;
    
    // Get final stats
    $stats = $conn->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
        FROM mail_blaster
        WHERE campaign_id = $campaign_id
    ")->fetch_assoc();
    
    logMessage("Parallel processing completed in " . round($elapsed, 2) . " seconds");
    logMessage("Stats - Total: {$stats['total']}, Success: {$stats['success']}, Failed: {$stats['failed']}");
    
    return [
        "status" => "success",
        "message" => "Email blast completed",
        "stats" => $stats,
        "elapsed_time" => round($elapsed, 2),
        "workers_launched" => count($processes)
    ];
}

/**
 * Retry failed emails with working servers
 */
function retryFailedEmails($conn, $campaign_id, $smtp_servers, $campaign, $retry_attempt = 1) {
    logMessage("Retry attempt #$retry_attempt: Checking for failed emails");
    
    // Get failed emails that haven't exceeded max attempts
    $max_attempts = MAX_RETRY_ATTEMPTS + 1; // +1 for initial attempt
    $failed_emails = $conn->query("
        SELECT DISTINCT mb.to_mail, e.id, mb.attempt_count
        FROM mail_blaster mb
        JOIN emails e ON e.raw_emailid = mb.to_mail
        WHERE mb.campaign_id = $campaign_id 
        AND mb.status = 'failed'
        AND mb.attempt_count < $max_attempts
        AND NOT EXISTS (
            SELECT 1 FROM mail_blaster mb2 
            WHERE mb2.to_mail = mb.to_mail 
            AND mb2.campaign_id = $campaign_id
            AND mb2.status = 'success'
        )
        ORDER BY mb.attempt_count ASC, mb.delivery_time DESC
        LIMIT 1000
    ")->fetch_all(MYSQLI_ASSOC);
    
    if (empty($failed_emails)) {
        logMessage("No failed emails to retry (attempt #$retry_attempt)");
        return 0;
    }
    
    logMessage("Found " . count($failed_emails) . " failed emails to retry (attempt #$retry_attempt)");
    
    // Delete old failed records so they can be retried
    $email_list = array_map(function($e) use ($conn) {
        return "'" . $conn->real_escape_string($e['to_mail']) . "'";
    }, $failed_emails);
    $email_list_str = implode(',', $email_list);
    
    $conn->query("
        DELETE FROM mail_blaster 
        WHERE campaign_id = $campaign_id 
        AND to_mail IN ($email_list_str)
        AND status = 'failed'
    ");
    
    logMessage("Cleared " . $conn->affected_rows . " failed records for retry");
    
    // Distribute failed emails across working servers
    $batch_config = calculateBatchConfig(count($failed_emails), 
        array_sum(array_map(function($s) { return count($s['accounts']); }, $smtp_servers)), 
        count($smtp_servers));
    
    $distribution = distributeEmailsAcrossServers($failed_emails, $smtp_servers, $batch_config);
    
    // Launch retry workers
    launchParallelWorkers($conn, $campaign_id, $distribution, $campaign);
    
    // Wait for retry workers to complete
    sleep(3);
    
    return count($failed_emails);
}

/**
 * Update final campaign statistics
 */
function updateFinalCampaignStats($conn, $campaign_id) {
    logMessage("Updating final campaign statistics for campaign #$campaign_id");
    
    // Get accurate counts from mail_blaster table
    $stats = $conn->query("
        SELECT 
            COUNT(DISTINCT CASE WHEN mb.status = 'success' THEN mb.to_mail END) as sent_count,
            COUNT(DISTINCT CASE WHEN mb.status = 'failed' THEN mb.to_mail END) as failed_count
        FROM mail_blaster mb
        WHERE mb.campaign_id = $campaign_id
    ")->fetch_assoc();
    
    $sent_emails = intval($stats['sent_count']);
    $failed_emails = intval($stats['failed_count']);
    
    // Get total emails for this campaign
    $total_result = $conn->query("
        SELECT COUNT(DISTINCT e.raw_emailid) as total
        FROM emails e
        WHERE e.domain_status = 1
    ");
    $total_emails = intval($total_result->fetch_assoc()['total']);
    
    $pending_emails = max(0, $total_emails - $sent_emails - $failed_emails);
    
    // Determine campaign status
    $campaign_status = 'running';
    if ($pending_emails == 0) {
        $campaign_status = 'completed';
        logMessage("Campaign #$campaign_id COMPLETED - All emails processed (100%)");
    }
    
    // Update campaign_status with accurate numbers
    $conn->query("
        UPDATE campaign_status 
        SET 
            sent_emails = $sent_emails,
            failed_emails = $failed_emails,
            pending_emails = $pending_emails,
            total_emails = $total_emails,
            status = '$campaign_status',
            end_time = CASE WHEN '$campaign_status' = 'completed' THEN NOW() ELSE end_time END
        WHERE campaign_id = $campaign_id
    ");
    
    logMessage("Final stats: Total=$total_emails, Sent=$sent_emails, Failed=$failed_emails, Pending=$pending_emails, Status=$campaign_status");
    
    return [
        'total_emails' => $total_emails,
        'sent_emails' => $sent_emails,
        'failed_emails' => $failed_emails,
        'pending_emails' => $pending_emails,
        'status' => $campaign_status
    ];
}

/**
 * Create worker script
 */
function createWorkerScript() {
    if (file_exists(WORKER_SCRIPT)) {
        return;
    }
    
    $worker_code = <<<'WORKER_PHP'
<?php
// Email Blast Worker Script
// This script is spawned by the parallel email blaster to send emails in parallel

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';

error_reporting(E_ALL);
ini_set('display_errors', 0);
set_time_limit(0);

// Parse arguments
$campaign_id = isset($argv[1]) ? intval($argv[1]) : 0;
$email_ids_str = isset($argv[2]) ? $argv[2] : '';
$server_config = isset($argv[3]) ? json_decode($argv[3], true) : [];
$account_config = isset($argv[4]) ? json_decode($argv[4], true) : [];
$campaign = isset($argv[5]) ? json_decode($argv[5], true) : [];

if ($campaign_id == 0 || empty($email_ids_str) || empty($server_config) || empty($account_config)) {
    exit(1);
}

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'CRM');
$conn->set_charset("utf8mb4");
if ($conn->connect_error) {
    exit(1);
}

// Get email IDs
$email_ids = array_filter(explode(',', $email_ids_str), 'is_numeric');
if (empty($email_ids)) {
    exit(0);
}

// Fetch emails
$id_list = implode(',', $email_ids);
$result = $conn->query("
    SELECT id, raw_emailid FROM emails 
    WHERE id IN ($id_list) AND domain_status = 1
");

$emails = [];
while ($row = $result->fetch_assoc()) {
    $emails[] = $row;
}

// Process each email
foreach ($emails as $email) {
    try {
        sendEmail($conn, $campaign_id, $email['raw_emailid'], $server_config, $account_config, $campaign);
        usleep(100000); // 100ms between emails
    } catch (Exception $e) {
        // Error already logged in sendEmail
    }
}

$conn->close();
exit(0);

/**
 * Send email using PHPMailer
 */
function sendEmail($conn, $campaign_id, $to_email, $server, $account, $campaign) {
    // Validate email format before attempting to send
    if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Invalid email format: $to_email");
    }
    
    $to_email = trim($to_email);
    if (empty($to_email) || strlen($to_email) > 254) {
        throw new Exception("Email address too long or empty: $to_email");
    }
    
    $mail = new PHPMailer(true);
    
    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = $server['host'];
        $mail->Port = $server['port'];
        $mail->SMTPAuth = true;
        $mail->Username = $account['email'];
        $mail->Password = $account['password'];
        $mail->Timeout = 30;
        $mail->SMTPDebug = 0;
        $mail->SMTPKeepAlive = false;
        
        if ($server['encryption'] === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($server['encryption'] === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }
        
        // Enhanced SMTPOptions for maximum compatibility - CRITICAL!
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
                'crypto_method' => STREAM_CRYPTO_METHOD_TLS_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT
            ]
        ];
        
        // Enable automatic retry on connection failure
        $mail->SMTPAutoTLS = true;
        
        $mail->setFrom($account['email']);
        $mail->addAddress($to_email);
        $mail->Subject = $campaign['mail_subject'];
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        
        // Add headers for better deliverability
        $mail->XMailer = ' '; // Hide X-Mailer header to avoid spam filters
        $mail->addCustomHeader('MIME-Version', '1.0');
        $mail->addCustomHeader('X-Priority', '3');
        $mail->addCustomHeader('X-MSMail-Priority', 'Normal');
        $mail->addCustomHeader('Importance', 'Normal');
        
        // Set HTML mode
        $isHtml = !empty($campaign['send_as_html']);
        $mail->isHTML($isHtml);
        
        // Reply-To with proper clearing
        if (!empty($campaign['reply_to'])) {
            $mail->clearReplyTos();
            $mail->addReplyTo($campaign['reply_to']);
        } elseif (!empty($server['received_email'])) {
            $mail->clearReplyTos();
            $mail->addReplyTo($server['received_email']);
        }
        
        // Add attachment
        if (!empty($campaign['attachment_path'])) {
            $attachmentPath = __DIR__ . '/../' . $campaign['attachment_path'];
            if (file_exists($attachmentPath)) {
                $mail->addAttachment($attachmentPath);
            }
        }
        
        // Process body
        $body = $campaign['mail_body'];
        
        // Validate body is not empty
        if (empty(trim($body))) {
            throw new Exception("Message body is empty. Cannot send email to $to_email");
        }
        
        // Add embedded images
        if (!empty($campaign['images_paths'])) {
            $images = is_string($campaign['images_paths']) 
                ? json_decode($campaign['images_paths'], true) 
                : $campaign['images_paths'];
            
            if (is_array($images)) {
                foreach ($images as $index => $imagePath) {
                    $fullPath = __DIR__ . '/../' . $imagePath;
                    if (file_exists($fullPath)) {
                        $cid = 'image_' . $index . '_' . uniqid();
                        $mail->addEmbeddedImage($fullPath, $cid);
                        
                        if ($isHtml) {
                            $filename = basename($imagePath);
                            $escapedPath = preg_quote($imagePath, '/');
                            $escapedFilename = preg_quote($filename, '/');
                            
                            $count = 0;
                            $body = preg_replace(
                                '/(<img[^>]+src=["\'])[^"\']*' . $escapedPath . '(["\'])/i',
                                '${1}cid:' . $cid . '${2}',
                                $body,
                                -1,
                                $count
                            );
                            
                            if ($count == 0) {
                                $body = preg_replace(
                                    '/(<img[^>]+src=["\'])[^"\']*' . $escapedFilename . '(["\'])/i',
                                    '${1}cid:' . $cid . '${2}',
                                    $body
                                );
                            }
                        }
                    }
                }
            }
        }
        
        $mail->Body = $body;
        if ($isHtml) {
            $mail->AltBody = strip_tags($body);
        }
        
        // Final validation before sending
        if (empty(trim($mail->Body))) {
            throw new Exception("Message body became empty during processing");
        }
        
        // Send email
        if (!$mail->send()) {
            throw new Exception($mail->ErrorInfo);
        }
        
        // Record success
        recordDelivery($conn, $account['id'], $campaign_id, $to_email, 'success');
        updateCampaignStats($conn, $campaign_id, 'success');
        
    } catch (Exception $e) {
        // Record failure
        recordDelivery($conn, $account['id'], $campaign_id, $to_email, 'failed', $e->getMessage());
        updateCampaignStats($conn, $campaign_id, 'failed');
    }
}

function recordDelivery($conn, $smtp_account_id, $campaign_id, $to_email, $status, $error = null) {
    // Check if this email was already sent successfully
    $check = $conn->query("
        SELECT status FROM mail_blaster 
        WHERE campaign_id = $campaign_id AND to_mail = '$to_email' AND status = 'success'
        LIMIT 1
    ");
    
    if ($check && $check->num_rows > 0) {
        // Already sent successfully, don't record again
        return;
    }
    
    $stmt = $conn->prepare("
        INSERT INTO mail_blaster 
        (campaign_id, to_mail, smtpid, delivery_date, delivery_time, status, error_message, attempt_count)
        VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, ?, 1)
        ON DUPLICATE KEY UPDATE
            smtpid = VALUES(smtpid),
            delivery_date = VALUES(delivery_date),
            delivery_time = VALUES(delivery_time),
            status = IF(mail_blaster.status = 'success', 'success', VALUES(status)),
            error_message = IF(VALUES(status) = 'failed', VALUES(error_message), NULL),
            attempt_count = IF(mail_blaster.status = 'success', mail_blaster.attempt_count, mail_blaster.attempt_count + 1)
    ");
    
    $stmt->bind_param("isiss", $campaign_id, $to_email, $smtp_account_id, $status, $error);
    $stmt->execute();
    $stmt->close();
    
    // Update SMTP account counters if email was sent successfully
    if ($status === 'success') {
        $conn->query("
            UPDATE smtp_accounts 
            SET sent_today = sent_today + 1,
                total_sent = total_sent + 1
            WHERE id = $smtp_account_id
        ");
    }
}

function updateCampaignStats($conn, $campaign_id, $result) {
    // Don't update stats here - will be recalculated at the end
    // This prevents double counting and mismatches
    return;
}
WORKER_PHP;
    
    file_put_contents(WORKER_SCRIPT, $worker_code);
    chmod(WORKER_SCRIPT, 0755);
    logMessage("Worker script created at " . WORKER_SCRIPT);
}

/**
 * Log message to file
 */
function logMessage($message) {
    $logDir = dirname(LOG_FILE);
    if (!is_dir($logDir)) {
        mkdir($logDir, 0777, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp] $message" . PHP_EOL;
    file_put_contents(LOG_FILE, $logEntry, FILE_APPEND);
}

/**
 * Check network connectivity
 */
function checkNetworkConnectivity() {
    $connected = @fsockopen("8.8.8.8", 53, $errno, $errstr, 5);
    if ($connected) {
        fclose($connected);
        return true;
    }
    return false;
}

// ========================================
// MAIN DAEMON LOOP
// ========================================

logMessage("=== Starting Parallel Email Blast Daemon for Campaign #$campaign_id ===");

while (true) {
    try {
        // Reconnect to database for each cycle
        $conn = new mysqli("127.0.0.1", "root", "", "CRM");
        $conn->set_charset("utf8mb4");
        if ($conn->connect_error) {
            logMessage("Database connection failed: " . $conn->connect_error);
            sleep(10);
            continue;
        }

        // Check campaign status
        $status_result = $conn->query("
            SELECT status, total_emails, sent_emails, pending_emails, failed_emails
            FROM campaign_status 
            WHERE campaign_id = $campaign_id
        ");

        if ($status_result->num_rows === 0) {
            logMessage("Campaign not found. Exiting daemon.");
            $conn->close();
            break;
        }

        $campaign_data = $status_result->fetch_assoc();
        $status = $campaign_data['status'];

        if ($status !== 'running') {
            logMessage("Campaign status is '$status'. Exiting daemon.");
            $conn->close();
            break;
        }

        // Check network connectivity
        if (!checkNetworkConnectivity()) {
            logMessage("Network connection unavailable. Waiting to retry...");
            $conn->close();
            sleep(60);
            continue;
        }

        // Check if there are emails remaining to send
        $remaining_result = $conn->query("
            SELECT COUNT(*) as remaining FROM emails e
            WHERE e.domain_status = 1
            AND NOT EXISTS (
                SELECT 1 FROM mail_blaster mb 
                WHERE mb.to_mail = e.raw_emailid 
                AND mb.campaign_id = $campaign_id
                AND mb.status = 'success'
            )
        ");
        
        $remaining_count = $remaining_result->fetch_assoc()['remaining'];

        if ($remaining_count == 0) {
            $conn->query("UPDATE campaign_status 
                         SET status = 'completed', pending_emails = 0, end_time = NOW() 
                         WHERE campaign_id = $campaign_id");
            logMessage("All emails processed. Campaign completed. Exiting daemon.");
            $conn->close();
            break;
        }

        logMessage("--- Starting parallel blast cycle for $remaining_count emails ---");
        
        // Execute one cycle of parallel email blast
        $result = runParallelEmailBlast($conn, $campaign_id);
        
        logMessage("Cycle completed: " . json_encode($result));
        
        // Check status again after cycle
        $status_check = $conn->query("SELECT status FROM campaign_status WHERE campaign_id = $campaign_id")->fetch_assoc();
        if ($status_check['status'] !== 'running') {
            logMessage("Campaign status changed to '{$status_check['status']}'. Exiting daemon.");
            $conn->close();
            break;
        }
        
        // Small delay before next cycle
        $conn->close();
        sleep(2); // 2 seconds between cycles
        
    } catch (Exception $e) {
        logMessage("Error in daemon loop: " . $e->getMessage());
        if (isset($conn)) {
            $conn->close();
        }
        sleep(10); // Wait before retry on error
    }
}

logMessage("=== Parallel Email Blast Daemon Stopped for Campaign #$campaign_id ===");
