<?php
// Direct API endpoint for email upload/processing
require_once __DIR__ . '/../public/email_processor.php';
