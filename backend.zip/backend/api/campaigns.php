<?php
// Direct API endpoint for campaigns
require_once __DIR__ . '/../includes/campaign.php';
