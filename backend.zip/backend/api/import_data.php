<?php
// Direct API endpoint for import data operations
require_once __DIR__ . '/../includes/import_data.php';
