<?php
// Direct API endpoint for campaign master operations (status/operations)
require_once __DIR__ . '/../public/campaigns_master.php';
