<?php
// Direct API endpoint for SMTP servers
require_once __DIR__ . '/../includes/master_smtps.php';
