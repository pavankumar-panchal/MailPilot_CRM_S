<?php
// Direct API endpoint for workers
require_once __DIR__ . '/../includes/workers.php';
