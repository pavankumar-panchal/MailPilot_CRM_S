<?php
// Direct API endpoint for mail templates
require_once __DIR__ . '/../includes/mail_templates.php';
