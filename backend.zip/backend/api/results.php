<?php
// Direct API endpoint for results
require_once __DIR__ . '/../includes/get_results.php';
