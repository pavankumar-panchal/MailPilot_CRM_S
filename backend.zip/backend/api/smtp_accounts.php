<?php
// Direct API endpoint for SMTP accounts
require_once __DIR__ . '/../includes/smtp_accounts.php';
