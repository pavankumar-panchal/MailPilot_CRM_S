# MailPilot CRM Deployment Instructions

## Prerequisites
- SSH access to payrollsoft.in server
- File upload capability (SCP, SFTP, or FTP)
- Server path: `/home/payrolls/public_html/emailvalidation`

## Deployment Steps

### 1. Upload Packages
Upload both `frontend.tar.gz` and `backend.tar.gz` to your server.

### 2. Backup Current Installation
```bash
ssh payrolls@payrollsoft.in
cd /home/payrolls/public_html/emailvalidation
# Backup current installation
tar -czf backup-$(date +%Y%m%d_%H%M%S).tar.gz dist/ backend/ --exclude='backend/logs' --exclude='backend/tmp'
```

### 3. Deploy Frontend
```bash
cd /home/payrolls/public_html/emailvalidation
# Remove old dist
rm -rf dist
mkdir dist
# Extract new frontend
tar -xzf frontend.tar.gz -C dist/
chmod -R 755 dist/
```

### 4. Deploy Backend
```bash
cd /home/payrolls/public_html/emailvalidation
# Extract backend (this will overwrite existing files)
tar -xzf backend.tar.gz
chmod -R 755 backend/
# Ensure log/tmp directories have correct permissions
chmod 775 backend/logs backend/tmp
```

### 5. Test Database Connection
```bash
cd /home/payrolls/public_html/emailvalidation/backend/scripts
php test_db_connection.php
```

### 6. Verify API Endpoints
```bash
# Test campaigns list
curl -X POST 'https://payrollsoft.in/emailvalidation/backend/routes/api.php/api/master/campaigns_master' \
  -H 'Content-Type: application/json' \
  -d '{"action":"list"}' | jq .
```

### 7. Clear Browser Cache
- Clear browser cache or use Ctrl+Shift+R (hard reload)
- Test the application at: https://payrollsoft.in/emailvalidation

## Logs Location
After deployment, monitor these log files for issues:
- `backend/logs/campaigns_master_api.log` - Campaign API operations
- `backend/logs/orchestrator_N.log` - Email sending orchestrator (N = campaign_id)
- `backend/logs/email_blast_parallel_YYYY-MM-DD.log` - Parallel email blast daemon
- `backend/logs/db_error.log` - Database connection errors

## Troubleshooting
If campaigns don't load:
1. Check `backend/logs/campaigns_master_api.log`
2. Run `backend/scripts/test_db_connection.php`
3. Verify database credentials in `backend/config/db.php`

If emails don't send when clicking "Send":
1. Check `backend/logs/orchestrator_N.log` where N is campaign ID
2. Check `backend/logs/email_blast_parallel_*.log`
3. Verify SMTP accounts are active
4. Check file permissions on `backend/tmp/` and `backend/logs/`
